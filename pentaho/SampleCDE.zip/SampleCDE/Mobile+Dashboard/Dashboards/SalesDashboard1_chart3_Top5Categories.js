lib('cdf-env.js');

var render_chart3_Top5Categories = {
  type: "cccPieChart",
  name: "render_chart3_Top5Categories",
  priority: 5,
  parameters: [["param1_FromDate","param1_FromDate"],["param2_ToDate","param2_ToDate"]],
  executeAtStart: true,
  htmlObject: "Panel3",
  preExecution: function f(){
var myself = this;
  // Set initial width to match the placeholder
  myself.chartDefinition.width = myself.placeholder().width();

  // Attach the resize handler only on the first execution of the chart component
  if (!this.resizeHandlerAttached){

    // Ensure render is only triggered after resize events have stopped
    var debouncedResize = _.debounce(function(){

      // Show chart again.
      myself.placeholder().children().css('visibility','visible');

      // Change chart width
      myself.chartDefinition.width = myself.placeholder().width();
      myself.render( myself.query.lastResults() );
    }, 200);

    // Attach resize handler
    $(window).resize(function(){

      // Only trigger resize if the container has changed width
      if ( myself.chartDefinition.width != myself.placeholder().width()){

        // Temporarily hide chart so that overflow does not happen
        myself.placeholder().children().css('visibility','hidden');

        // Trigger the resize with debounce
        debouncedResize();
      }    
    });

    this.resizeHandlerAttached = true;
  }
  
},
  listeners: ['${p:param1_FromDate}','${p:param2_ToDate}'],
  chartDefinition:  {
    dataAccessId: "query3_Top5Categories",
    path: "/home/admin/SampleCDE/Mobile Dashboard/Dashboards/SalesDashboard1.cda",
    width: 300,
    height: 180,
    extensionPoints: [["slice_innerRadiusEx","80%"],["slice_add",function() {            var pctBorderOffsetRadius = 0.01;                         return new pv.Dot()                .localProperty('layoutInfo')                .data(function(scene){ return [scene]; })                .layoutInfo(function() {                    return  this.getContext().panel._layoutInfo;                })                .zOrder(-5)                 .bottom(function(){ return this.layoutInfo().center.y; })                .left  (function(){ return this.layoutInfo().center.x; })                .shapeRadius(function(){                    var li = this.layoutInfo();                    var borderOffsetRadius = pctBorderOffsetRadius * li.clientRadius;                    var maxPieOffsetRadius = li.explodedOffsetRadius + li.activeOffsetRadius;                    var borderRadius = li.normalRadius +                                         maxPieOffsetRadius +                                         borderOffsetRadius;                    return this.getContext().chart.animate(10, borderRadius);                })                .fillStyle(null)                .strokeStyle('gray')                .lineWidth(1);         }]],
    colors: [],
    activeSliceRadius: "5%",
    animate: true,
    clearSelectionMode: "emptySpaceClick",
    clickable: true,
    clickAction: function f(wedge) {
    
    Dashboards.fireChange('inparam3_CategoryName', wedge.vars.category.value);
  //  alert("you have clicked on"+" "+inparam3_CategoryName);
   

},
    colorPreserveMap: false,
    compatVersion: 2,
    contentMargins: "0",
    contentPaddings: "0",
    crosstabMode: true,
    ctrlSelectMode: true,
    dataIgnoreMetadataLabels: false,
    dataMeasuresInColumns: false,
    dataSeparator: "~",
    explodedSliceRadius: "0",
    groupedLabelSep: " ~ ",
    hoverable: true,
    ignoreNulls: true,
    isMultiValued: false,
    legend: true,
    legendClickMode: "toggleVisible",
    legendFont: "10px sans-serif",
    legendItemPadding: "2.5",
    legendMargins: "0",
    legendMarkerSize: 15,
    legendOverflow: "clip",
    legendPaddings: "5",
    legendPosition: "bottom",
    legendShape: "circle",
    legendTextMargin: 6,
    legendVisible: true,
    linkHandleWidth: 0.5,
    linkInsetRadius: "5%",
    linkLabelSize: "15%",
    linkLabelSpacingMin: 0.5,
    linkMargin: "2.5%",
    linkOutsetRadius: "2.5%",
    margins: "3",
    measuresIndexes: [],
    multiChartColumnsMax: 3,
    multiChartIndexes: [],
    multiChartOverflow: "grow",
    multiChartSingleColFillsHeight: true,
    multiChartSingleRowFillsHeight: true,
    paddings: "0",
    pointingMode: "near",
    preserveLayout: false,
    readers: [],
    selectable: true,
    seriesInRows: false,
    slidingWindow: false,
    smallContentMargins: "0",
    smallContentPaddings: "0",
    smallMargins: "2%",
    smallPaddings: "0",
    smallTitleFont: "14px sans-serif",
    smallTitleMargins: "0",
    smallTitlePaddings: "0",
    smallTitlePosition: "top",
    timeSeries: false,
    timeSeriesFormat: "%Y-%m-%d",
    titleFont: "14px sans-serif",
    titleMargins: "0",
    titlePaddings: "0",
    titlePosition: "top",
    tooltipEnabled: true,
    tooltipFade: true,
    tooltipFollowMouse: false,
    tooltipHtml: true,
    tooltipOpacity: 0.9,
    valuesFont: "10px sans-serif",
    valuesLabelStyle: "linked",
    valuesOverflow: "hide",
    valuesVisible: false
  }
};

cgg.initParameter
("param1_FromDate", "param1_FromDate")
("param2_ToDate", "param2_ToDate")
;

cgg.render(render_chart3_Top5Categories);
