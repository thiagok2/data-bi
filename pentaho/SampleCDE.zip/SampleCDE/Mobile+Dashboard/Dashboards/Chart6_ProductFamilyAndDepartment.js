lib('cdf-env.js');

var render_Chart6_ProductFamilyAndDepartment = {
  type: "cccTreemapChart",
  name: "render_Chart6_ProductFamilyAndDepartment",
  priority: 5,
  parameters: [["param1_FromDate","param1_FromDate"],["param2_ToDate","param2_ToDate"]],
  executeAtStart: true,
  htmlObject: "Panel6",
  preExecution: function f()  {
    this.cccType = pvc.SunburstChart;
    // Set any sunburst specific properties not available as same-named Treemap CDE properties here.
    // this.chartDefinition
var myself = this;
  // Set initial width to match the placeholder
  myself.chartDefinition.width = myself.placeholder().width();

  // Attach the resize handler only on the first execution of the chart component
  if (!this.resizeHandlerAttached){

    // Ensure render is only triggered after resize events have stopped
    var debouncedResize = _.debounce(function(){

      // Show chart again.
      myself.placeholder().children().css('visibility','visible');

      // Change chart width
      myself.chartDefinition.width = myself.placeholder().width();
      myself.render( myself.query.lastResults() );
    }, 200);

    // Attach resize handler
    $(window).resize(function(){

      // Only trigger resize if the container has changed width
      if ( myself.chartDefinition.width != myself.placeholder().width()){

        // Temporarily hide chart so that overflow does not happen
        myself.placeholder().children().css('visibility','hidden');

        // Trigger the resize with debounce
        debouncedResize();
      }    
    });

    this.resizeHandlerAttached = true;
  }

    
},
  listeners: ['${p:param1_FromDate}','${p:param2_ToDate}'],
  chartDefinition:  {
    dataAccessId: "query6_Product_FamilyAndDepartment",
    path: "/home/admin/SampleCDE/Mobile Dashboard/Dashboards/SalesDashboard1.cda",
    width: 200,
    height: 180,
    extensionPoints: [],
    colors: [],
    animate: true,
    clearSelectionMode: "emptySpaceClick",
    clickable: true,
    colorMode: "byParent",
    colorPreserveMap: false,
    compatVersion: 2,
    contentMargins: "0",
    contentPaddings: "0",
    crosstabMode: false,
    ctrlSelectMode: true,
    dataIgnoreMetadataLabels: false,
    dataMeasuresInColumns: false,
    dataSeparator: "~",
    groupedLabelSep: " ~ ",
    hoverable: true,
    ignoreNulls: true,
    isMultiValued: false,
    layoutMode: "squarify",
    legend: true,
    legendClickMode: "toggleVisible",
    legendFont: "10px sans-serif",
    legendItemPadding: "2.5",
    legendMargins: "0",
    legendMarkerSize: 15,
    legendOverflow: "clip",
    legendPaddings: "5",
    legendPosition: "bottom",
    legendTextMargin: 6,
    legendVisible: true,
    margins: "3",
    measuresIndexes: [],
    multiChartColumnsMax: 3,
    multiChartIndexes: [],
    multiChartOverflow: "grow",
    multiChartSingleColFillsHeight: true,
    multiChartSingleRowFillsHeight: true,
    orientation: "vertical",
    paddings: "0",
    pointingMode: "near",
    preserveLayout: false,
    readers: [],
    rootCategoryLabel: "All",
    selectable: true,
    seriesInRows: false,
    sizeAxisDomainAlign: "center",
    sizeAxisUseAbs: false,
    slidingWindow: false,
    smallContentMargins: "0",
    smallContentPaddings: "0",
    smallMargins: "2%",
    smallPaddings: "0",
    smallTitleFont: "14px sans-serif",
    smallTitleMargins: "0",
    smallTitlePaddings: "0",
    smallTitlePosition: "top",
    titleFont: "14px sans-serif",
    titleMargins: "0",
    titlePaddings: "0",
    titlePosition: "top",
    tooltipEnabled: true,
    tooltipFade: true,
    tooltipFollowMouse: false,
    tooltipHtml: true,
    tooltipOpacity: 0.9,
    valuesFont: "10px sans-serif",
    valuesOverflow: "hide"
  }
};

cgg.initParameter
("param1_FromDate", "param1_FromDate")
("param2_ToDate", "param2_ToDate")
;

cgg.render(render_Chart6_ProductFamilyAndDepartment);
