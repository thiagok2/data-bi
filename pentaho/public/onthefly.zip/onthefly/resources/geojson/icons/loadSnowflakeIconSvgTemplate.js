define(['text!../img/snowflake_icon.svg'], function(icon) {
    return {
        icon: icon
    };
});