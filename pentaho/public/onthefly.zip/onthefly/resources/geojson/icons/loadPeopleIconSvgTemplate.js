define(['text!../img/people_icon.svg'], function(icon) {
    return {
        icon: icon
    };
});